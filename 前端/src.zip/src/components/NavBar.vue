<template>
    <nav class="navbar navbar-dark bg-dark">
        <div class="container">
            <img src="https://cdn.acwing.com/media/user/profile/photo/222713_lg_d6fd8c4861.PNG">
            <a class="navbar-brand">首页</a>

            <div class="dropdown">
                <a href="#" class="dropbtn navbar-brand">国内青训</a>
                <div class="dropdown-content">
                    <a href="#">球队名1</a>
                    <a href="#">球队名2</a>
                    <a href="#">球队名3</a>
                    <a href="#">球队名4</a>
                    <a href="#">球队名5</a>
                    <a href="#">球队名6</a>
                    <a href="#">球队名7</a>
                    <a href="#">球队名8</a>
                    <a href="#">......</a>
                </div>
            </div>

            <a class="navbar-brand">留洋球员</a>
            <a class="navbar-brand">排行榜</a>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="输入球员姓名搜索" aria-label="Search">
                <button class="btn btn-primary" type="submit">搜索</button>
            </form>
        </div>
    </nav>

</template>

<script>



export default {
    name: "NavBar",
    components: {

    },


}




</script>

<style scoped>
.navbar-brand {
    font-size: 30px;
}

img {
    width: 130px;
    border-radius: 50%;
}

* {
    box-sizing: border-box;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

/* 为每个链接设定样式 */
.dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

/* 鼠标放置链接时改变样式 */
.dropbtn:hover {
    background-color: #111;
    color: red;
}

.dropdown {
    display: inline-block;

}

/* 下拉菜单设置样式 */
.dropdown-content {
    /* 隐藏菜单 */
    display: none;
    position: absolute;
    background-color: hsl(0, 0%, 98%);
    /* 设置链接元素的最小宽度 */
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(12, 12, 12, 0.2);
    overflow: auto;
}

.dropdown-content a {
    display: block;
    color: black;
    padding: 12px 16px;
    text-decoration: none;

}

.dropdown-content a:hover {
    background-color: #f1f1f1
}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>